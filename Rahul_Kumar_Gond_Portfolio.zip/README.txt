RAHUL KUMAR GOND — PROFESSIONAL PORTFOLIO

Open index.html in Chrome or Edge.
The portfolio is self-contained: photo and network topology are embedded.

Featured project:
Small Office Network — Cisco Packet Tracer
- Router + switch topology
- VLAN 10 / VLAN 20
- DHCP
- IP addressing
- Router-on-a-stick inter-VLAN routing
- Connectivity validation

The sample Cisco commands are representative and should be adapted to the exact Packet Tracer device/interface model used.
